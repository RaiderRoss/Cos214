#include "Sensor.h"
#include "Group.h"
Sensor::Sensor(Group* g) {
    group = g;
}

Sensor::~Sensor() {
}
