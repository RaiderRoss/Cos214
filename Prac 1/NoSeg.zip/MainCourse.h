#ifndef MainCourse_H
#define MainCourse_H
#include <iostream>
#include "Course.h"
class MainCourse : public Course
{
private:
    /* data */
public:
    MainCourse(int maxNumberOfItems);
    void recommendBeverage();
};

#endif