#include "Menu.h"
Menu::Menu() {

}
bool Menu::addCourse(Course *course) {
  if (course != NULL) {
    if (courses.find(course->getDescription()) == courses.end()) {
      courses.insert({course->getDescription(), course});
      return true;
    }
  }
  return false;
}

bool Menu::addMenuItem(std::string courseDescription, std::string description, float price, int stock) {
  if (courses.find(courseDescription) == courses.end()) {
    return false;
  }
  Course *course = courses[courseDescription];
  if (course != NULL) {
    return course->addMenuItem(description, price, stock);
  }
  return false;
}

void Menu::printMenu() const {
  for (std::pair<const std::string, Course *> course : courses) {
    if (course.second != NULL) {
      std::cout << course.first << std::endl;
      course.second->printMenuItems();
    }
  }
}

void Menu::inventory() const {
  for (std::pair<const std::string, Course *> course : courses) {
    if (course.second != NULL) {
      std::cout << course.first << std::endl;
      course.second->printInventory();
    }
  }
}

float Menu::orderItem(std::string courseDescription, char item) {
  if (courses.find(courseDescription) != courses.end()) {
    Course *course = courses[courseDescription];
    if (course != NULL) {
      int index = item - 'a';
      if (index >= 0) {  
        MenuItem *menuItem = course->getMenuItem(index);
        if (menuItem != NULL) {
          if (menuItem->getStock() > 0) {
            menuItem->reduceStock();
            return menuItem->getPrice();
          }
        }
      }
    }
  }
  return 0;
}

bool Menu::isCoursesEmpty() {
  return courses.empty();
}

void Menu::closeShop() {
  std::cout << "Closing shop. Deleting all " << courses.size() << " courses" << std::endl;
  for (std::pair<const std::string, Course *> &pair : courses) {
    if (pair.second != NULL) {
      delete pair.second;
      pair.second = NULL;
    }
  }
  courses.clear();
}

Menu::~Menu() {
  std::cout << "Menu destructor called" << std::endl;
  if (!courses.empty()) {
    closeShop();
  }
}
