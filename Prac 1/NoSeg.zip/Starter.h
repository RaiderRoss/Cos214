#ifndef Starter_H
#define Starter_H
#include "Course.h"
#include <iostream>
class Starter : public Course{
private:
public:
    Starter(int maxNumberOfItems);
    void recommendBeverage();
};

#endif