#ifndef Dessert_H
#define Dessert_H
#include <iostream>
#include "Course.h"
class Dessert : public Course
{
private:

public:
    Dessert(int maxNumberOfItems);
    virtual void recommendBeverage();
};

#endif