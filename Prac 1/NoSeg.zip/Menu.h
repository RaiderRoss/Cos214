#ifndef Menu_H
#define Menu_H
#include <map>
#include "Course.h"
#include <string>
class Menu
{
private:
  std::map<std::string, Course*> courses;
public:
    Menu();
    bool addCourse(Course *course);
    bool addMenuItem(std::string courseDescription, std::string description, float price, int stock);
    void printMenu() const;
    void inventory() const;
    float orderItem(std::string courseDescription, char item);
    bool isCoursesEmpty();
    void closeShop();
    ~Menu();
};

#endif