#ifndef Course_H
#define Course_H
#include <string>
#include <iostream>
#include "MenuItem.h"
#include <vector>
class Course
{
protected:
    std::string description;
    int maxNumberOfItems;
    std::vector<MenuItem *> menuItems;
public:
    Course(std::string description, int maxNumberOfItems);
    std::string getDescription();
    bool addMenuItem(std::string description, float price, int stock);
    void printMenuItems();
    void printInventory();
    MenuItem *getMenuItem(int index);
    virtual void recommendBeverage() = 0;
    virtual ~Course();
};

#endif