#include "Course.h"
Course::Course(std::string description, int maxNumberOfItems) {
  this->description = description;
  this->maxNumberOfItems = maxNumberOfItems;
}

std::string Course::getDescription() {
  return description;
}

bool Course::addMenuItem(std::string description, float price, int stock) {
  if (menuItems.size() < maxNumberOfItems) {
    menuItems.push_back(new MenuItem(description, price, stock));
    return true;
  }
  return false;
}

void Course::printMenuItems() {
  char a = 97;
  for (MenuItem *item : menuItems) {
    if (item != NULL) {
      std::cout << "\t" << a << "." << "\t" << item->getDescription() << "\n";
      a++;
    }
  }
}

void Course::printInventory() {
  char a = 97;
  for (MenuItem *item : menuItems) {
    if (item != NULL) {
      std::cout << "\t" << a << "." << "\t" << item->getDescription() << "\t" << item->getPrice() << "\t" << item->getStock() << std::endl;
      a++;
    }
  }
}

MenuItem *Course::getMenuItem(int index) {
  if (index >= 0 && index < menuItems.size()) {
    if (menuItems[index] != NULL) {  
      return menuItems[index];
    }
  }
  return NULL;
}

Course::~Course() {
  for (MenuItem *item : menuItems) {
    if (item != NULL) {
      delete item;
      item = NULL;
    }
  }
  menuItems.clear();
}
