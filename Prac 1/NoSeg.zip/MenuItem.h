#ifndef MenuItem_H
#define MenuItem_H
#include <string>
#include <iostream>
class MenuItem
{
private:
    std::string description;
    float price;
    int stock;
public:
    MenuItem(std::string description, float price, int stock);
    std::string getDescription();
    float getPrice();
    int getStock();
    void reduceStock();
};
#endif