//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "OpenFieldCavalry.h"

void OpenfieldCavalry::move() {
    std::cout << "Moving the horses into open field with lush grass" << std::endl;
}

void OpenfieldCavalry::attack() {
    std::cout << "Horses run up from behind and destory some units" << std::endl;
}

OpenfieldCavalry::OpenfieldCavalry() {
}
