//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "WoodlandArtillery.h"

void WoodlandArtillery::move() {
    std::cout << "Moving Artillery into the forest, maybe not a good idea" << std::endl;
}

void WoodlandArtillery::attack() {
    std::cout << "Permission denied, we don't want to hit a branch and the mortor falls back down!" << std::endl;
}

WoodlandArtillery::WoodlandArtillery() {
}
