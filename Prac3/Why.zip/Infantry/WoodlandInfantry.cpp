//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "WoodlandInfantry.h"

void WoodlandInfatry::move() {
    std::cout << "Retreating into the forest for cover" << std::endl;
}

void WoodlandInfatry::attack() {
    std::cout << "Ambushesh enemy forces trying to escape through the forest" << std::endl;
}

WoodlandInfatry::WoodlandInfatry() {
}
