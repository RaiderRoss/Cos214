//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "WoodlandCavalry.h"

void WoodlandCavalry::move() {
    std::cout << "Horses gallop into the forest" << std::endl;
}

void WoodlandCavalry::attack() {
    std::cout << "The cavalry charges out of the trees with their long swords drawn" << std::endl;
}

WoodlandCavalry::WoodlandCavalry() {
}
