#include "LegionUnit.h"
LegionUnit::LegionUnit() {
}

LegionUnit::~LegionUnit() {
}
