//
// Created by 2MGOU on 2024/08/20.
//

#ifndef FORTIFICATION_H
#define FORTIFICATION_H



class Fortification {

};



#endif //FORTIFICATION_H
