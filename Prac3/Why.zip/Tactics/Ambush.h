//
// Created by 2MGOU on 2024/08/20.
//

#ifndef AMBUSH_H
#define AMBUSH_H



class Ambush {

};



#endif //AMBUSH_H
