//
// Created by 2MGOU on 2024/08/20.
//

#ifndef FLANKING_H
#define FLANKING_H



class Flanking {

};



#endif //FLANKING_H
