//
// Created by 2MGOU on 2024/08/20.
//

#ifndef WARARCHIVES_H
#define WARARCHIVES_H



class WarArchives {

};



#endif //WARARCHIVES_H
