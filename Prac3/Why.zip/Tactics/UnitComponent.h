//
// Created by 2MGOU on 2024/08/20.
//

#ifndef UNITCOMPONENT_H
#define UNITCOMPONENT_H



class UnitComponent {

};



#endif //UNITCOMPONENT_H
