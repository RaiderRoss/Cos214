//
// Created by 2MGOU on 2024/08/20.
//

#ifndef TACTICALMEMENTO_H
#define TACTICALMEMENTO_H



class TacticalMemento {

};



#endif //TACTICALMEMENTO_H
