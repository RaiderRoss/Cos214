//
// Created by 2MGOU on 2024/08/20.
//

#ifndef TACTICALCOMMAND_H
#define TACTICALCOMMAND_H
#include "BattleStrategy.h"


class TacticalCommand {
public:
void setStrategy(BattleStrategy *s);
void chooseBestStrategy();
void executeStategy();
private:
BattleStrategy * strategy;
};



#endif //TACTICALCOMMAND_H
