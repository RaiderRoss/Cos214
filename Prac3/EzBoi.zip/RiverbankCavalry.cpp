//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "RiverbankCavalry.h"

void RiverbankCavalry::move() {
    std::cout << "Soldiers struggle to get their horses to walk on grainy sand" << std::endl;
}

void RiverbankCavalry::attack() {
    std::cout << "The horses fling soldiers off onto the ground and gallop off into the sunset" << std::endl;
}

RiverbankCavalry::RiverbankCavalry() {
}
