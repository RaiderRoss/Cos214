//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "OpenFieldArtillery.h"

void OpenFieldArtillery::move() {
    std::cout << "Moving Artillery into open field" << std::endl;
}

void OpenFieldArtillery::attack() {
      std::cout << "Sending random mortors into the fields" << std::endl;
}

OpenFieldArtillery::OpenFieldArtillery() {
}
