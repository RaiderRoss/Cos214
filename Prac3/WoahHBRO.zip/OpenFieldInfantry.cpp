//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "OpenFieldInfantry.h"

void OpenfieldInfantry::move() {
    std::cout << "Moving legions of infantry onto the battle field" << std::endl;
}

void OpenfieldInfantry::attack() {
    std::cout << "Brave soldiers charge out into the enemy forces" << std::endl;
}

OpenfieldInfantry::OpenfieldInfantry() {
}
