//
// Created by 2MGOU on 2024/08/20.
//

#include "Infantry.h"
#include "RiverbankArtillery.h"

void RiverbankArtillery::move() {
    std::cout << "Moving Artillery slowly onto sandy shores" << std::endl;
}

void RiverbankArtillery::attack() {
    std::cout << "Sending random mortors into the water ^@$#67 SPLASH" << std::endl;
}

RiverbankArtillery::RiverbankArtillery() {
}
