#include "Iterator.h"
#include "FarmLand.h"
Iterator::Iterator() {
}

Iterator::~Iterator() {
}


bool Iterator::isDone() {
	return false;
}
