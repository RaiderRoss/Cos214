#include "TruckerMan.h"
#include "FarmUnit.h"
TruckerMan::TruckerMan() {
}

TruckerMan::~TruckerMan() {
}
